package com.fln.apiflnmonitor.model;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

public record NoticiaDTO(  String titulo,
        String link,
        String tipo,
        LocalDateTime data,
        String fonte,
        String conteudo,
        String cidade) {

}
